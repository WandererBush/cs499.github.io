const passport = require('passport');
const LocalStrategy = require('passport-local').Strategy;
const JwtStrategy = require('passport-jwt').Strategy;
const ExtractJwt = require('passport-jwt').ExtractJwt;
const User = require('../models/user');
const { JWT_SECRET } = require('../models/user');

// LOCAL STRATEGY
// Used only on the /login endpoint to verify an email + password pair
// and issue a JWT. Every request after login uses the JWT strategy
// below instead, so passwords are only ever transmitted once.
passport.use(new LocalStrategy(
    { usernameField: 'email' },
    async (email, password, done) => {
        try {
            const user = await User.findOne({ email: email.toLowerCase() });
            if (!user) {
                return done(null, false, { message: 'Incorrect email or password.' });
            }
            if (!user.validPassword(password)) {
                return done(null, false, { message: 'Incorrect email or password.' });
            }
            return done(null, user);
        } catch (err) {
            return done(err);
        }
    }
));

// JWT STRATEGY
// Extracts the token from the Authorization: Bearer <token> header,
// verifies the signature/expiry, and attaches the decoded payload
// (id, email, role) to req.user for use by route handlers and the
// role-based access middleware.
const jwtOptions = {
    jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
    secretOrKey: JWT_SECRET
};

passport.use(new JwtStrategy(jwtOptions, async (payload, done) => {
    try {
        const user = await User.findById(payload._id);
        if (!user) {
            return done(null, false);
        }
        return done(null, user);
    } catch (err) {
        return done(err, false);
    }
}));

module.exports = passport;
