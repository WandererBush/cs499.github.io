const mongoose = require('mongoose');
const Trip = require('../models/travlr'); // Register model
const Model = mongoose.model('trips');
const tripIndex = require('../models/tripIndex');

// Loads every trip into the in-memory hash map index the first time it's
// needed. After this, code lookups and filtered searches read from the
// index instead of hitting Mongo, and writes (add/update) keep the index
// in sync via tripIndex.upsert() so it never goes stale.
const ensureIndexLoaded = async() => {
    if (tripIndex.loaded) return;

    const trips = await Model.find({}).exec();
    tripIndex.build(trips);
};

// GET: /trips - lists all the trips
// Regardless of outcome, response must include HTML status code
// and JSON message to the requesting client
const tripsList = async(req, res) => {
    const q = await Model
        .find({}) // No filter, return all records
        .exec();

        // Uncomment the following line to show results of querey
        // on the console
        // console.log(q);

    if(!q)
    { // Database returned no data
        return res
            .status(404)
            .json({ message: 'No trips found' });
    } else { // Return resulting trip list
        return res
            .status(200)
            .json(q);
    }
};

// DATABASE ENHANCEMENT - VALIDATION ERROR HANDLING
// Turns a Mongoose ValidationError (or a duplicate-key error from the
// unique index on code) into a clean, field-by-field message list the
// client can actually use, instead of the raw Mongoose error object.
const formatDbError = (err) => {
    if (err.name === 'ValidationError') {
        const errors = Object.values(err.errors).map(e => e.message);
        return { message: 'Validation failed', errors };
    }
    if (err.code === 11000) {
        return { message: `A trip with that code already exists` };
    }
    return { message: 'Unable to save trip', errors: [err.message] };
};

// POST: /trips - Adds a new Trip
// Regardless of outcome, response must include HTML status code
// and JSON message to the requesting client
const tripsAddTrip = async(req, res) => {
    const newTrip = new Trip({
        code: req.body.code,
        name: req.body.name,
        length: req.body.length,
        start: req.body.start,
        resort: req.body.resort,
        perPerson: req.body.perPerson,
        image: req.body.image,
        description: req.body.description
    });

    try {
        const q = await newTrip.save();

        if(!q)
        { // Database returned no data
            return res
                .status(400)
                .json({ message: 'Trip could not be saved' });
        } else { // Keep the hash map index in sync, then return new trip
            tripIndex.upsert(q);
            return res
                .status(201)
                .json(q);
        }
    } catch (err) {
        // Schema validation (or the unique code index) rejected the
        // write. Return the specific reason(s) instead of a bare 500.
        return res
            .status(400)
            .json(formatDbError(err));
    }
};

// PUT: /trips/:tripCode - Adds a new Trip
// Regardless of outcome, response must include HTML status code
// and JSON message to the requesting client
const tripsUpdateTrip = async(req, res) => {

    // Uncomment for debugging
    console.log(req.params);
    console.log(req.body);

    try {
        const q = await Model
            .findOneAndUpdate(
                { 'code' : req.params.tripCode },
                {
                    code: req.body.code,
                    name: req.body.name,
                    length: req.body.length,
                    start: req.body.start,
                    resort: req.body.resort,
                    perPerson: req.body.perPerson,
                    image: req.body.image,
                    description: req.body.description
                },
                {
                    new: true,        // return the updated doc, not the pre-update
                                       // one, so the hash map index gets fresh data
                    runValidators: true, // re-run schema validation on update too;
                                       // Mongoose skips this by default for
                                       // findOneAndUpdate
                    context: 'query'  // required by Mongoose for update validators
                                       // to resolve correctly
                }
            )
            .exec();

        if(!q)
        { // Database returned no data
            return res
                .status(404)
                .json({ message: 'Trip not found' });
        } else { // Keep the hash map index in sync, then return updated trip
            tripIndex.upsert(q);
            return res
                .status(201)
                .json(q);
        }
    } catch (err) {
        return res
            .status(400)
            .json(formatDbError(err));
    }
};

// GET: /trips/:tripCode - lists a single trip
// Previously this ran a fresh Mongo query on every request. It now reads
// from the in-memory hash map index instead, an O(1) average lookup
// rather than a collection query each time. If the index somehow misses
// (e.g. right after a cold start before it's finished loading), it falls
// back to the database so the endpoint stays correct either way.
const tripsFindByCode = async(req, res) => {
    await ensureIndexLoaded();

    let trip = tripIndex.getByCode(req.params.tripCode);

    if (!trip) {
        // Fallback path: not expected in normal operation, but keeps the
        // endpoint correct if the index and database ever disagree.
        trip = await Model.findOne({ 'code': req.params.tripCode }).exec();
        if (trip) tripIndex.upsert(trip);
    }

    if (!trip) { // No trip found by that code
        return res
            .status(404)
            .json({ message: 'Trip not found' });
    } else {
        return res
            .status(200)
            .json(trip);
    }
};

// GET: /trips/search?resort=...&maxPerPerson=...&length=...
// Filters trips using the hash map index instead of scanning the full
// trip list for every request. When a resort is given, the search starts
// from that resort's bucket (O(1) to reach it, O(k) to read it, where k
// is just the trips at that resort) instead of an O(n) scan of every
// trip in the catalog. Any remaining filters are then applied only to
// that narrowed set.
const tripsSearch = async(req, res) => {
    await ensureIndexLoaded();

    const { resort, maxPerPerson, length } = req.query;
    const results = tripIndex.search({ resort, maxPerPerson, length });

    return res
        .status(200)
        .json(results);
};

module.exports = {
    tripsList,
    tripsFindByCode,
    tripsSearch,
    tripsAddTrip,
    tripsUpdateTrip
};