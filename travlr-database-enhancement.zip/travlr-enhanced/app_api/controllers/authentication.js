const passport = require('passport');
const User = require('../models/user');

// POST /register
// Creates a new account. New accounts always default to the 'user'
// role; only an existing admin can promote someone to 'admin'
// (see users controller), so this endpoint can stay open for
// self-service signup without becoming a privilege-escalation risk.
const register = async (req, res) => {
    const { name, email, password } = req.body;

    if (!name || !email || !password) {
        return res.status(400).json({ message: 'All fields required' });
    }

    const user = new User({ name, email: email.toLowerCase() });
    user.setPassword(password);

    try {
        await user.save();
        return res.status(201).json({ token: user.generateJwt() });
    } catch (err) {
        // Duplicate email triggers a Mongo E11000 error
        if (err.code === 11000) {
            return res.status(409).json({ message: 'Email already registered' });
        }
        return res.status(400).json({ message: err.message });
    }
};

// POST /login
// Delegates credential checking to the Passport local strategy, then
// issues a JWT on success. The client stores this token and attaches
// it to future requests instead of resending the password.
const login = (req, res, next) => {
    if (!req.body.email || !req.body.password) {
        return res.status(400).json({ message: 'Email and password required' });
    }

    passport.authenticate('local', (err, user, info) => {
        if (err) return next(err);
        if (!user) {
            return res.status(401).json(info);
        }
        return res.status(200).json({ token: user.generateJwt(), role: user.role });
    })(req, res, next);
};

module.exports = { register, login };
