const passport = require('passport');

// requireAuth: verifies a valid JWT is present. On success it attaches
// the authenticated user to req.user; on failure it short-circuits
// with a 401 before the route handler ever runs.
const requireAuth = passport.authenticate('jwt', { session: false });

// requireRole: a small middleware factory so routes can declare which
// role they need, e.g. requireRole('admin'). Keeping this generic
// (rather than a hardcoded isAdmin check) means adding a new role
// later, like 'editor', doesn't require touching every route.
const requireRole = (...allowedRoles) => (req, res, next) => {
    if (!req.user || !allowedRoles.includes(req.user.role)) {
        return res.status(403).json({ message: 'Insufficient permissions' });
    }
    next();
};

module.exports = { requireAuth, requireRole };
