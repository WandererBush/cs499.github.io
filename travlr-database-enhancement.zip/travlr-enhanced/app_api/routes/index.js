const express = require('express'); // Express app
const router = express.Router();    // Router logic

// Controllers
const tripsController = require('../controllers/trips');
const authController = require('../controllers/authentication');

// RBAC / JWT middleware
const { requireAuth, requireRole } = require('../middleware/auth');

// AUTH ROUTES
// Public: anyone can register or attempt to log in.
router.post('/register', authController.register);
router.post('/login', authController.login);

// TRIPS ROUTES
// GET is public so the public-facing site can still list trips
// without logging in. POST/PUT now require a valid JWT AND the
// 'admin' role, since only staff should be able to create or
// modify trip listings.
router
    .route('/trips')
    .get(tripsController.tripsList)
    .post(requireAuth, requireRole('admin'), tripsController.tripsAddTrip);

// Must come before /trips/:tripCode, otherwise Express matches "search"
// as a trip code and this route never gets hit.
router
    .route('/trips/search')
    .get(tripsController.tripsSearch);

router
    .route('/trips/:tripCode')
    .get(tripsController.tripsFindByCode)
    .put(requireAuth, requireRole('admin'), tripsController.tripsUpdateTrip);

module.exports = router;
