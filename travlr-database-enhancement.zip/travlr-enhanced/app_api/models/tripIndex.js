// tripIndex.js
//
// In-memory hash map index for the Trip collection.
//
// PROBLEM THIS SOLVES:
// The original tripsFindByCode controller ran a fresh Mongo query
// (effectively an O(n) collection scan in the worst case, and always a
// round trip to the database) every single time a client asked for a
// trip by code. As the trip catalog grows, or as the admin panel and
// public site both hit these endpoints repeatedly, that cost adds up
// for data that barely ever changes between requests.
//
// This module builds two hash maps in memory:
//   - byCode:   code   -> trip        (O(1) average lookup by trip code)
//   - byResort: resort -> [ trips ]   (O(1) average bucket access, then
//                                      only that bucket is scanned instead
//                                      of the entire collection)
//
// Both maps are kept in sync incrementally through upsert(), so a single
// full O(n) rebuild only happens once (on first use), not on every
// request.

class TripIndex {
    constructor() {
        this.byCode = new Map();     // code (string)   -> trip document
        this.byResort = new Map();   // resort (string) -> array of trips
        this.loaded = false;
    }

    // Builds both hash maps from a full array of trips.
    // O(n) — this only runs once, the first time the index is needed.
    build(trips) {
        this.byCode.clear();
        this.byResort.clear();

        for (const trip of trips) {
            this._indexOne(trip);
        }

        this.loaded = true;
    }

    // Adds a brand new trip, or updates an existing one, in both maps.
    // O(1) average for the code map. O(b) for the resort bucket, where b
    // is the number of trips already at that resort (only relevant when
    // updating a trip that changed resorts, so the old bucket entry can
    // be removed) — still far cheaper than rebuilding the whole index.
    upsert(trip) {
        if (!trip || !trip.code) return;

        const existing = this.byCode.get(trip.code);

        // If the trip already existed under a different resort, pull it
        // out of that resort's bucket before re-indexing.
        if (existing && existing.resort && existing.resort !== trip.resort) {
            const oldBucket = this.byResort.get(existing.resort);
            if (oldBucket) {
                const i = oldBucket.findIndex(t => t.code === trip.code);
                if (i !== -1) oldBucket.splice(i, 1);
            }
        }

        this._indexOne(trip);
    }

    _indexOne(trip) {
        this.byCode.set(trip.code, trip);

        if (trip.resort) {
            const bucket = this.byResort.get(trip.resort);
            if (bucket) {
                const i = bucket.findIndex(t => t.code === trip.code);
                if (i !== -1) {
                    bucket[i] = trip; // replace existing entry in place
                } else {
                    bucket.push(trip);
                }
            } else {
                this.byResort.set(trip.resort, [trip]);
            }
        }
    }

    // O(1) average — replaces the old "scan every trip for a matching
    // code" approach with a direct hash map lookup.
    getByCode(code) {
        return this.byCode.get(code) || null;
    }

    // O(1) average to reach the right bucket, O(k) to return it, where k
    // is just the number of trips at that resort — not the whole catalog.
    getByResort(resort) {
        return this.byResort.get(resort) || [];
    }

    // Combines hash map filtering (resort) with a narrowed linear pass
    // for the remaining criteria (price ceiling, trip length). Because
    // the resort bucket is used as the starting point instead of the
    // full trip list, this only touches the trips that could possibly
    // match, instead of scanning the entire collection for every filter.
    search({ resort, maxPerPerson, length } = {}) {
        let candidates;

        if (resort) {
            candidates = this.getByResort(resort);
        } else {
            candidates = Array.from(this.byCode.values());
        }

        if (maxPerPerson !== undefined && maxPerPerson !== null && maxPerPerson !== '') {
            const ceiling = parseFloat(maxPerPerson);
            if (!Number.isNaN(ceiling)) {
                candidates = candidates.filter(trip => {
                    const price = parseFloat(String(trip.perPerson).replace(/[^0-9.]/g, ''));
                    return !Number.isNaN(price) && price <= ceiling;
                });
            }
        }

        if (length) {
            candidates = candidates.filter(trip => trip.length === length);
        }

        return candidates;
    }

    get size() {
        return this.byCode.size;
    }
}

// Singleton instance shared across the app for the lifetime of the process.
module.exports = new TripIndex();
