const mongoose = require('mongoose');
const crypto = require('crypto');
const jwt = require('jsonwebtoken');

// Secret used to sign JWTs. In production this should come from an
// environment variable (JWT_SECRET) rather than being hardcoded.
const JWT_SECRET = process.env.JWT_SECRET || 'travlr-dev-secret-change-me';

const userSchema = new mongoose.Schema({
    email: { type: String, required: true, unique: true, index: true },
    name: { type: String, required: true },
    hash: { type: String, required: true },
    salt: { type: String, required: true },
    // RBAC: every user has exactly one role. New accounts default to
    // 'user'; the 'admin' role is required to add or edit trips.
    role: { type: String, enum: ['user', 'admin'], default: 'user' }
});

// Generates a random salt and stores a salted hash of the password.
// Uses Node's built-in crypto module (pbkdf2) so there is no native
// dependency to compile, which keeps the enhancement easy to run
// in any Node environment.
userSchema.methods.setPassword = function (password) {
    this.salt = crypto.randomBytes(16).toString('hex');
    this.hash = crypto
        .pbkdf2Sync(password, this.salt, 10000, 64, 'sha512')
        .toString('hex');
};

// Recomputes the hash for a supplied password using the stored salt
// and compares it to the stored hash.
userSchema.methods.validPassword = function (password) {
    const hash = crypto
        .pbkdf2Sync(password, this.salt, 10000, 64, 'sha512')
        .toString('hex');
    return this.hash === hash;
};

// Issues a signed JWT that carries the user's id, email, and role.
// Including the role in the payload is what allows downstream
// middleware to make authorization decisions without a database
// round trip on every request.
userSchema.methods.generateJwt = function () {
    const payload = {
        _id: this._id,
        email: this.email,
        name: this.name,
        role: this.role
    };
    return jwt.sign(payload, JWT_SECRET, { expiresIn: '24h' });
};

module.exports = mongoose.model('User', userSchema);
module.exports.JWT_SECRET = JWT_SECRET;
