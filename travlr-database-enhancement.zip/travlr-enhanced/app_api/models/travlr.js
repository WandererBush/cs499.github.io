const mongoose = require('mongoose');

// Define the trip schema
//
// DATABASE ENHANCEMENT - SCHEMA VALIDATION
// The original schema only enforced that fields were present (required:
// true). It did not stop malformed data from reaching the database, for
// example a trip code with spaces or symbols, a negative or non-numeric
// price, or a one-character trip name. Because tripsAddTrip and
// tripsUpdateTrip pass req.body straight into the model with no checks
// of their own, the schema is the only place bad data gets caught before
// it is written to MongoDB. The rules below move that validation down to
// the data layer so every write path (API, admin panel, future scripts,
// direct Mongoose calls) is protected the same way, rather than relying
// on each caller to validate independently.
const tripSchema = new mongoose.Schema({
    code: {
        type: String,
        required: [true, 'Trip code is required'],
        unique: true,
        trim: true,
        uppercase: true,
        minlength: [3, 'Trip code must be at least 3 characters'],
        maxlength: [15, 'Trip code cannot exceed 15 characters'],
        match: [/^[A-Z0-9]+$/, 'Trip code may only contain letters and numbers']
    },
    name: {
        type: String,
        required: [true, 'Trip name is required'],
        trim: true,
        minlength: [3, 'Trip name must be at least 3 characters'],
        maxlength: [100, 'Trip name cannot exceed 100 characters']
    },
    length: {
        type: String,
        required: [true, 'Trip length is required'],
        trim: true
    },
    start: {
        type: Date,
        required: [true, 'Start date is required'],
        validate: {
            validator: v => v instanceof Date && !isNaN(v),
            message: 'Start date must be a valid date'
        }
    },
    resort: {
        type: String,
        required: [true, 'Resort is required'],
        trim: true,
        minlength: [2, 'Resort name must be at least 2 characters']
    },
    perPerson: {
        type: String,
        required: [true, 'Price per person is required'],
        match: [/^\d+(\.\d{1,2})?$/, 'Price per person must be a valid number, e.g. 799 or 799.00']
    },
    image: {
        type: String,
        required: [true, 'Image filename is required'],
        trim: true
    },
    description: {
        type: String,
        required: [true, 'Description is required'],
        trim: true,
        minlength: [10, 'Description must be at least 10 characters']
    }
}, {
    // Adds createdAt / updatedAt automatically, useful for auditing when
    // a trip record was added or last changed.
    timestamps: true
});

const Trip = mongoose.model('trips', tripSchema);
module.exports = Trip;
