import { HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { AuthService } from '../services/auth.service';

// Attaches "Authorization: Bearer <token>" to every outgoing request
// when a token is present. This is what lets the Express-side
// requireAuth/requireRole middleware identify the logged-in user
// without the component code having to manage headers manually.
export const jwtInterceptor: HttpInterceptorFn = (req, next) => {
  const auth = inject(AuthService);
  const token = auth.getToken();

  if (token) {
    req = req.clone({
      setHeaders: { Authorization: `Bearer ${token}` }
    });
  }

  return next(req);
};
