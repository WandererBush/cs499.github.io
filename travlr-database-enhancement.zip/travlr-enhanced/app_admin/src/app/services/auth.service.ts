import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, tap } from 'rxjs';

interface AuthResponse {
  token: string;
  role?: string;
}

// Decoded shape of our JWT payload (see app_api/models/user.js generateJwt)
interface JwtPayload {
  _id: string;
  email: string;
  name: string;
  role: 'user' | 'admin';
  exp: number;
}

@Injectable({ providedIn: 'root' })
export class AuthService {
  private tokenKey = 'travlr_token';
  private baseUrl = 'http://localhost:3000/api';

  constructor(private http: HttpClient) {}

  login(email: string, password: string): Observable<AuthResponse> {
    return this.http
      .post<AuthResponse>(`${this.baseUrl}/login`, { email, password })
      .pipe(tap(res => localStorage.setItem(this.tokenKey, res.token)));
  }

  register(name: string, email: string, password: string): Observable<AuthResponse> {
    return this.http
      .post<AuthResponse>(`${this.baseUrl}/register`, { name, email, password })
      .pipe(tap(res => localStorage.setItem(this.tokenKey, res.token)));
  }

  logout(): void {
    localStorage.removeItem(this.tokenKey);
  }

  getToken(): string | null {
    return localStorage.getItem(this.tokenKey);
  }

  isLoggedIn(): boolean {
    const payload = this.decodedToken();
    if (!payload) return false;
    // exp is in seconds since epoch; Date.now() is in ms
    return payload.exp * 1000 > Date.now();
  }

  // RBAC on the client: used by the route guard and by templates that
  // want to hide/show admin-only controls (e.g. the "Add Trip" button).
  // This is a UX convenience only, not a security boundary; the real
  // enforcement happens server-side via requireRole in app_api.
  getRole(): string | null {
    return this.decodedToken()?.role ?? null;
  }

  isAdmin(): boolean {
    return this.getRole() === 'admin';
  }

  private decodedToken(): JwtPayload | null {
    const token = this.getToken();
    if (!token) return null;
    try {
      const payloadSegment = token.split('.')[1];
      const json = atob(payloadSegment.replace(/-/g, '+').replace(/_/g, '/'));
      return JSON.parse(json) as JwtPayload;
    } catch {
      return null;
    }
  }
}
