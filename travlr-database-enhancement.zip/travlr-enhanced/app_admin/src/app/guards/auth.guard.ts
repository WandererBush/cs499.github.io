import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthService } from '../services/auth.service';

// Guards the add-trip / edit-trip routes so an unauthenticated user,
// or a logged-in user without the 'admin' role, is redirected to the
// login page instead of ever rendering the form. This mirrors the
// server-side RBAC check but at the routing layer for a clean UX.
export const authGuard: CanActivateFn = () => {
  const auth = inject(AuthService);
  const router = inject(Router);

  if (auth.isLoggedIn() && auth.isAdmin()) {
    return true;
  }

  router.navigate(['/login']);
  return false;
};
